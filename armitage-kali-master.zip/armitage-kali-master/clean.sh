#!/bin/bash

set -ex

./gradlew clean

rm -rf release