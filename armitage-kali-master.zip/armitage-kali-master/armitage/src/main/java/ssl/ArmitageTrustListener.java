package ssl;

public interface ArmitageTrustListener {
	public boolean trust(String fingerprint);
}
