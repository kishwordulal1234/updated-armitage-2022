package armitage;

import javax.swing.JLabel;

public interface Activity {
	public void registerLabel(JLabel label);
	public void resetNotification();
}
