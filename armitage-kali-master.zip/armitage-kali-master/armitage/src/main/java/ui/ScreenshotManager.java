package ui;

import java.awt.Image;

public interface ScreenshotManager {
	public void saveScreenshot(Image screenshot, String title);
}
